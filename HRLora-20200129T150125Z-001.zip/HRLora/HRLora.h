#ifndef tl
#define tl

#if (ARDUINO >=100)
  #include "Arduino.h"
#else
  #include "WProgram.h"
#endif

class HRLora  {
  public:
    // Constructor 
    HRLora(String uid="");

    // Methods
    void begin();
    void send(String msg="");

  private:
    String _uid;
    void getResponse();
    String stringToHex(String s);
    void chipSET(String command);
	void MillisDelay(int period);
};
#endif
