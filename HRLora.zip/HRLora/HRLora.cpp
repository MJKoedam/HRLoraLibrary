#include "HRLora.h"

// Constructor
HRLora::HRLora(String uid) {
  // Anything you need when instantiating your object goes here
  _uid = uid;
}

void HRLora::begin(){
  while (_uid == "") {				//uid can't be empty
    Serial.println("[HRLoRa] Error: UID is empty");
  }
  Serial.println("[HRLora] UID succesfully registered!");
  Serial1.begin(57600);				//Serial1begin to send the commands directly to the LoRachip (RN2483)
  Serial.println("[HRLora] Serial1 initiated on a baudrate of 57600");
  //Starting the setup
  Serial.println("[HRLoRa] Chip connection established!");
  Serial.println("[HRLoRa] Configuring chip");
  
  chipSET("radio set freq 868000000");
  Serial.println("[HRLoRa] Frequency succesfully set to 868MHz");
  chipSET("radio set sync 52");
  Serial.println("[HRLoRa] Sync succesfully set to 52");
  chipSET("radio set bw 125");
  Serial.println("[HRLoRa] Bandwidth succesfully set to 125");
  chipSET("radio set sf sf7");
  Serial.println("[HRLoRa] Sf succesfully set to sf7");
  chipSET("radio set cr 4/5");
  Serial.println("[HRLoRa] Cr succesfully set to 4/5");
  chipSET("mac set ch status 1 off");
  Serial.println("[HRLoRa] Channel 1 is succesfully turned off");
  chipSET("mac set ch status 2 off");
  Serial.println("[HRLoRa] Channel 2 is succesfully turned off");
  Serial.println("[HRLoRa] Channel 0 is now the fixex channel");
  chipSET("mac set ch dcycle 0 1");
  Serial.println("[HRLoRa] The duty cycle of channel 0 is succesfully set to 1");
  
  Serial.println("[HRLoRa] Setup done");
}

// public Methods

// For transmitting data;
void HRLora::send(String msg) {		//sending the uid key and the message as a hexadecimal
  Serial.println("[HRLoRa] Sending message: uid=" + _uid  +"&" + msg);
  Serial1.println("radio tx "+ stringToHex("uid=" + _uid  +"&" + msg));
  delay(250);
}

// Private functions
void HRLora::chipSET(String command) {
  Serial1.println(command);
  String content = "";
  char character;
  delay(25);  						//minimal delay between 20-25, needed to send the command
  while (Serial1.available()) {
    content += Serial1.read();
  }
  if (content == "1111071310") {	//check for ok-response
	  Serial.println("[HRLoRa] " + command + ": ok");
  }
  else {
    Serial.println("[HRLoRa] Failed to get 'ok'-response, calling command again: " + command);
	delay(500);
    chipSET(command);
  }
}

String HRLora::stringToHex(String s) {	//the function to set the string to hexadecimals
  int stringLength = s.length() + 1;
  char charArray[stringLength];
  String hexString = "";
  s.toCharArray(charArray, stringLength);
  for (int a = 0; a < stringLength - 1; a++) {
    byte byteRead = charArray[a];
    hexString = hexString + String(byteRead, HEX);
  }
  return hexString;
}
